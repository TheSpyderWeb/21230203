const mealsEl = document.getElementById("meals");
const favoriteContainer = document.getElementById("fav-meals");
const mealPopup = document.getElementById("meal-popup");
const mealInfoEl = document.getElementById("meal-info");
const popupCloseBtn = document.getElementById("close-popup");

const searchTerm = document.getElementById("search-term");
const searchBtn = document.getElementById("search");

getRandomMeal();
fetchFavMeals();

async function getRandomMeal() {
  const resp = await fetch(
    "https://www.themealdb.com/api/json/v1/1/random.php"
  );
  const respData = await resp.json();
  const randomMeal = respData.meals[0];
  addMeal(randomMeal, true);
}

async function getMealById(id) {
  const resp = await fetch(
    "https://www.themealdb.com/api/json/v1/1/lookup.php?i=" + id
  );
  const respData = await resp.json();
  const meal = respData.meals[0];

  return meal;
}

async function getMealsBySearch(term) {
  const resp = await fetch(
    "https://www.themealdb.com/api/json/v1/1/search.php?s=" + term
  );
  const respData = await resp.json();
  const meals = respData.meals;
  return meals;
}

function addMeal(mealData, random = false) {
  console.log(mealData);

  const meal = document.createElement("div");
  meal.classList.add("meal");

  meal.innerHTML = `
        <div class="meal-header">
            ${
              random
                ? `
            <span class="random"> Random Recipe </span>`
                : ""
            }
            <img
                src="${mealData.strMealThumb}"
                alt="${mealData.strMeal}"
            />
        </div>
        <div class="meal-body">
            <h4>${mealData.strMeal}</h4>
            <button class="fav-btn">
                <i class="fas fa-heart"></i>
            </button>
        </div>
    `;

  const btn = meal.querySelector(".meal-body .fav-btn");

  btn.addEventListener("click", () => {
    if (btn.classList.contains("active")) {
      removeMealLS(mealData.idMeal);
      btn.classList.remove("active");
    } else {
      addMealLS(mealData.idMeal);
      btn.classList.add("active");
    }

    fetchFavMeals();
  });

  meal.addEventListener("click", () => {
    showMealInfo(mealData);
  });

  mealsEl.appendChild(meal);
}

function addMealLS(mealId) {
  const mealIds = getMealsLS();

  localStorage.setItem("mealIds", JSON.stringify([...mealIds, mealId]));
}

function removeMealLS(mealId) {
  const mealIds = getMealsLS();

  localStorage.setItem(
    "mealIds",
    JSON.stringify(mealIds.filter((id) => id !== mealId))
  );
}

function getMealsLS() {
  const mealIds = JSON.parse(localStorage.getItem("mealIds"));

  return mealIds === null ? [] : mealIds;
}

async function fetchFavMeals() {
  //clean the container
  favoriteContainer.innerHTML = "";

  const mealIds = getMealsLS();

  for (let i = 0; i < mealIds.length; i++) {
    const mealId = mealIds[i];
    meal = await getMealById(mealId);

    addMealFav(meal);
  }
}

function addMealFav(mealData) {
  const favMeal = document.createElement("li");

  favMeal.innerHTML = `
    <img
       src="${mealData.strMealThumb}"
       alt="${mealData.strMeal}"
    />
    <span>${mealData.strMeal}</span>
    <button class="clear"><i class="fas fa-window-close"></i></button>
    `;

  const btn = favMeal.querySelector(".clear");

  btn.addEventListener("click", () => {
    removeMealLS(mealData.idMeal);

    fetchFavMeals();
  });

  favMeal.addEventListener("click", () => {
    showMealInfo(mealData);
  });

  favoriteContainer.appendChild(favMeal);
}

function showMealInfo(mealData) {
  //clean it up
  mealInfoEl.innerHTML = "";

  //update the Meal Info

  const mealEl = document.createElement("div");

  const ingredients = [];

  for (let i = 1; i <= 20; i++) {
    if (mealData["strIngredient" + i]) {
      ingredients.push(
        `${mealData["strIngredient" + i]} - ${mealData["strMeasure" + i]}`
      );
    } else {
      break;
    }
  }

  mealEl.innerHTML = `
    <h1>${mealData.strMeal}</h1>
    <img
        src="${mealData.strMealThumb}"
        alt="${mealData.strMeal}"
    />

    <p>
      ${mealData.strInstructions}
    </p>

    <h3>Ingredients:</h3>
    <ul>
      ${ingredients
        .map(
          (ing) => `
          <li>${ing}</li>
          `
        )
        .join("")}
    </ul>
    `;

  mealInfoEl.appendChild(mealEl);
  mealPopup.classList.remove("hidden");

  mealPopup.classList.add("show");

}

searchBtn.addEventListener("click", async () => {
  //clean container
  mealsEl.innerHTML = "";

  const search = searchTerm.value;
  const meals = await getMealsBySearch(search);

  if (meals) {
    meals.forEach((meal) => {
      addMeal(meal);
    });
  }
});

popupCloseBtn.addEventListener("click", () => {
  mealPopup.classList.add("hidden");
});

function sendMessage() {
  const userInput = document.getElementById("user-input").value;
  if (userInput.trim() !== "") {
    appendMessage(userInput, "user");
    document.getElementById("user-input").value = "";

    // Simulate bot response
    setTimeout(() => {
      const botResponse = generateBotResponse(userInput);
      appendMessage(botResponse, "bot");
    }, 1000);
  }
}

function appendMessage(message, sender) {
  const chatDisplay = document.getElementById("chat-display");
  const messageDiv = document.createElement("div");
  messageDiv.classList.add("message", `${sender}-message`);
  messageDiv.innerHTML = `<p>${message}</p>`;
  chatDisplay.appendChild(messageDiv);
  chatDisplay.scrollTop = chatDisplay.scrollHeight;
}

function generateBotResponse(userMessage) {
  // Simple response based on keywords
  const responses = {
    "hello": "Hi there! Looking for food inspiration? How can I assist you?",
    "what's for dinner?": "How about some pasta or a delicious burger?",
    "what is your favorite food?": "If I could taste, I'd probably love pizza! It's so versatile!",
    "what is a good recipe?": "A classic spaghetti carbonara always hits the spot. Want the recipe?",
    "tell me a food fact": "Did you know that honey never spoils? Archaeologists have found pots of honey in ancient tombs that are over 3,000 years old!",
    "bye": "Goodbye! Enjoy your meal, and feel free to come back for more food talk!"
  };

  const lowerCaseMessage = userMessage.toLowerCase();
  return responses[lowerCaseMessage] || "Sorry, I didn't quite understand that.";
}


// Register User
function registerUser(event) {
  event.preventDefault();
  const fullName = document.getElementById('signup-fullname').value;
  const email = document.getElementById('signup-email').value;
  const username = document.getElementById('signup-username').value;
  const password = document.getElementById('signup-password').value;

  const users = JSON.parse(localStorage.getItem('users')) || [];
  
  if (users.some(user => user.username === username)) {
    alert('Username already exists. Please choose another.');
    return;
  }

  users.push({ fullName, email, username, password });
  localStorage.setItem('users', JSON.stringify(users));

  alert('Sign up successful! You can now log in.');
  window.location.href = 'login.html';
}

// Login User
function loginUser(event) {
  event.preventDefault();
  const username = document.getElementById('login-username').value;
  const password = document.getElementById('login-password').value;

  const users = JSON.parse(localStorage.getItem('users')) || [];
  const user = users.find(u => u.username === username && u.password === password);

  if (user) {
    localStorage.setItem('activeUser', JSON.stringify(user));
    alert('Login successful!');
    window.location.href = 'profile.html';
  } else {
    alert('Invalid username or password.');
  }
}

document.addEventListener('DOMContentLoaded', () => {
  const activeUser = JSON.parse(localStorage.getItem('activeUser'));

 /* if (!activeUser) {
    alert('No active user. Please log in.');
    window.location.href = 'login.html';
    return;
  }*/

  // Populate profile fields
  document.getElementById('full-name').value = activeUser.fullName;
  document.getElementById('email-address').value = activeUser.email;
  document.getElementById('username').value = activeUser.username;
  document.getElementById('password').value = activeUser.password;
});

function saveProfile() {
  const fullName = document.getElementById('full-name').value.trim();
  const email = document.getElementById('email-address').value.trim();
  const username = document.getElementById('username').value.trim();
  const password = document.getElementById('password').value;

  if (!fullName || !email || !username || !password) {
    alert('Please fill out all fields.');
    return;
  }

  const users = JSON.parse(localStorage.getItem('users')) || [];
  const activeUser = JSON.parse(localStorage.getItem('activeUser'));

  const updatedUser = { fullName, email, username, password };
  const userIndex = users.findIndex(user => user.username === activeUser.username);

  users[userIndex] = updatedUser;
  localStorage.setItem('users', JSON.stringify(users));
  localStorage.setItem('activeUser', JSON.stringify(updatedUser));

  alert('Profile updated successfully!');
}
